# app/services/interview/qa_reconstructor.py

import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

async def reconstruct_qa_blocks(questions: list[str], answers: list[str]) -> list[dict]:
    prompt = f"""
당신은 면접 리포트를 작성하는 평가 전문가입니다.

다음은 실제 면접 질문 5개입니다:
{chr(10).join([f"{i+1}. {q}" for i, q in enumerate(questions)])}

그리고 아래는 지원자의 전체 답변입니다:
{chr(10).join([f"- {a}" for a in answers])}

각 질문에 가장 잘 대응되는 답변을 매칭하여, 아래 형식으로 정리하세요:

[질문 1]
(질문 내용)
[답변]
(해당 질문에 대한 적절한 답변)

※ 답변이 짧거나 겹치면 가장 잘 대응되는 것 1개만 매칭해주세요.
"""
    response = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )

    return response.choices[0].message.content.strip()
