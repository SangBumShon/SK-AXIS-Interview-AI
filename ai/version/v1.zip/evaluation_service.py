# app/services/interview/evaluation_service.py
import time
import os
from dotenv import load_dotenv
import openai
from app.constants.evaluation_constants_full_all import (
    EVAL_CRITERIA_WITH_ALL_SCORES,
    TECHNICAL_EVAL_CRITERIA_WITH_ALL_SCORES
)

# Load API key
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

SYSTEM_PROMPT = """
당신은 기업 면접 평가 전문가입니다. 지원자의 전체 답변을 읽고 아래 항목에 따라 각 키워드에 대해 평가해주세요:

1. 관련 키워드 판단 (SUPEX, VWBE, 5P, Professional, 기술/직무)
2. 각 키워드에 대해 3개 평가 항목별 점수 (1~5점)
3. 항목별 평가 이유와 관련된 모든 문장 인용

결과는 다음 JSON 형식으로 출력하십시오:
{
  "키워드": {
    "항목명": {
      "score": int (1~5),
      "quotes": ["...", "..."],
      "reason": "..."
    },
    ...
  },
  ...
}
"""

USER_TEMPLATE = "지원자의 전체 면접 답변:
{answer}

위 지침에 따라 평가를 수행해주세요."

async def evaluate_keywords_from_full_answer(
    full_answer: str
) -> dict:
    prompt = USER_TEMPLATE.format(answer=full_answer)

    start = time.perf_counter()
    try:
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2,
            max_tokens=1600
        )
        elapsed = round(time.perf_counter() - start, 2)
        print(f"✅ 평가 완료 ({elapsed}초 소요)")
        content = response.choices[0].message.content
        return parse_llm_keyword_evaluation(content)

    except Exception as e:
        print(f"❌ GPT 평가 오류: {e}")
        return {}


def parse_llm_keyword_evaluation(raw: str) -> dict:
    """
    LLM 응답을 안전하게 파싱합니다. JSON 형식이 아닐 경우 수동 보정 필요
    """
    import json
    try:
        result = json.loads(raw)
        return result
    except json.JSONDecodeError:
        print("⚠️ JSON 파싱 오류. 수동 보정 필요")
        return {}


# 벡터 기반 키워드 검색 보조
# from app.services.vector_service import search_related_keywords

# def enrich_evaluation_with_keywords(answer_text: str) -> str:
#     related = search_related_keywords(answer_text)
#     keyword_summary = "\n".join(f"- {r['term']}: {r['description']}" for r in related)
#     return keyword_summary
# from langchain_community.chat_models import ChatOpenAI
# from langchain.prompts import ChatPromptTemplate
# from langchain.chains import LLMChain

# from dotenv import load_dotenv
# import os

# load_dotenv()

# openai_key = os.getenv("OPENAI_API_KEY")
# if not openai_key:
#     raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다. .env 파일을 확인하세요.")

# chat_model = ChatOpenAI(
#     model="gpt-4o",
#     temperature=0.0,
#     openai_api_key=openai_key
# )

# def evaluate_answer(answer: str) -> str:
#     """
#     면접 답변을 평가하는 함수
#     :param answer: 면접 답변 텍스트
#     :return: 평가 결과 텍스트
#     """
#     prompt = ChatPromptTemplate.from_template(
#         "다음 면접 답변을 평가해 주세요:\n\n{answer}\n\n"
#         "평가 기준:\n"
#         "- 답변의 명확성, 일관성, 관련성\n"
#         "- 어휘 사용과 문법적 정확성\n"
#         "- 전체적인 표현력과 설득력\n"
#         "평가 기준을 0점에서 5점 사이로 점수화하고, 각 기준에 대한 설명을 포함해 주세요.\n"
#         "평가 결과를 간결하게 요약해 주세요."
#     )

#     chain = LLMChain(llm=chat_model, prompt=prompt)
#     response = chain.run(answer=answer)

#     return response.strip()