# app/pipeline/pipeline_states.py
from langgraph import Graph
from datetime import datetime
import os

# 서비스 함수 임포트
from app.services.interview.stt_service import transcribe_audio_file
from app.services.interview.rewrite_service import rewrite_answer
from app.services.interview.evaluation_service import evaluate_keywords_from_full_answer
from app.services.interview.report_service import create_radar_chart, generate_pdf

# LangGraph 그래프 인스턴스
graph = Graph()

# ──────────────── 상태(state) 구조 ────────────────
# 각 에이전트/노드 호출 시 인자로 전달됩니다.
# 지원자 단위로 독립 실행 가능하도록 설계되었습니다.
#
# state = {
#     "interviewee_id": str,
#     "interview_ended": bool,
#     "stt": {"done": bool, "segments": [{"raw": str, "timestamp": str}, ...]},
#     "rewrite": {"done": bool, "items": [{"raw": str, "rewritten": str, "ok": bool|None, "judge_notes": [str]}]},
#     "decision_log": [{"step": str, "result": str, "time": str, "details": dict}],
#     "evaluation": {"done": bool, "results": dict|None, "ok": bool|None, "judge_notes": [str]},
#     "report": {"pdf": {"generated": bool, "path": str|None}, "excel": {"generated": bool, "path": str|None}}
# }

# ──────────────── 노드 및 에이전트 정의 ────────────────

# stt node
@graph.node(name="stt_node")
def stt_node(state: dict) -> dict:
    """
    1) audio_path 를 읽어 STT 수행
    2) state['stt']['segments']에 원문+타임스탬프 추가
    """
    audio_path = state.get("audio_path")
    interviewee_id = state["interviewee_id"]
    # Whisper API 호출 (이미 WAV 포맷으로 전달된다고 가정)
    raw = transcribe_audio_file(audio_path)
    ts = datetime.now().isoformat()
    # segments 누적
    state.setdefault("stt", {"done": False, "segments": []})
    state["stt"]["segments"].append({"raw": raw, "timestamp": ts})
    state["decision_log"].append({
        "step": "stt_node",
        "result": "success",
        "time": ts,
        "details": {"segment": raw[:30]}  # preview
    })
    return state

# rewrite agent
@graph.agent(name="rewrite_agent")
async def rewrite_agent(state: dict) -> dict:
    """
    1) 가장 최근 STT segment 원문을 **의미 변화나 요약 없이** 정제(rewrite)
       - 문법 오류, 오탈자, 공백만 수정
    2) state['rewrite']['items']에 raw, rewritten, ok=None, judge_notes=[] 추가
    """
    """
    1) 가장 최근 STT segment 원문을 rewrite
    2) state['rewrite']['items']에 raw, rewritten, ok=None, judge_notes=[] 추가
    """
    raw = state["stt"]["segments"][-1]["raw"]
    rewritten, _ = await rewrite_answer(raw)
    item = {"raw": raw, "rewritten": rewritten, "ok": None, "judge_notes": []}
    state.setdefault("rewrite", {"done": False, "items": []})
    state["rewrite"]["items"].append(item)
    ts = datetime.now().isoformat()
    state["decision_log"].append({
        "step": "rewrite_agent",
        "result": "processing",
        "time": ts,
        "details": {"raw_preview": raw[:30]}
    })
    return state

# rewrite judge agent
@graph.agent(name="judge_rewrite")
async def judge_rewrite(state: dict) -> dict:
    """
    1) raw vs rewritten 비교하여 ok/false 결정
    2) 마지막 rewrite item에 ok 및 judge_notes 업데이트
    """
    import json
    import openai
    from numpy import dot
    from numpy.linalg import norm
    # Get latest item
    item = state["rewrite"]["items"][-1]
    raw = item["raw"]
    rewritten = item["rewritten"]
    notes = []
    ok = True
    # 1) 단순 길이 비율 검사
    raw_len = len(raw)
    rew_len = len(rewritten)
    ratio = rew_len / raw_len if raw_len else 1.0
    if ratio < 0.8 or ratio > 1.2:
        ok = False
        notes.append(f"Length ratio {ratio:.2f} out of bounds (0.8~1.2)")
    # 2) (Optional) 의미 유사도 검사: embedding 비용/속도 고려, 필요 시 활성화
    # {
    # raw_vec = openai.embeddings.create(model="text-embedding-ada-002", input=raw)["data"][0]["embedding"]
    # rew_vec = openai.embeddings.create(model="text-embedding-ada-002", input=rewritten)["data"][0]["embedding"]
    # sim = dot(raw_vec, rew_vec) / (norm(raw_vec) * norm(rew_vec))
    # if sim < 0.8:
    #     ok = False
    #     notes.append(f"Semantic similarity {sim:.2f} below threshold (0.8)")
    # }
    # 3) GPT 기반 품질 검증
    if ok:
        prompt = f"""
시스템: 당신은 텍스트 리라이팅 평가 전문가입니다.
원본: \"{raw}\"
리라이팅: \"{rewritten}\"
1) 의미 보존
2) 과잉 축약/확장
3) 오탈자/문맥 오류
위 기준에 따라 JSON 형식으로 ok(bool)와 notes(list)를 반환하세요.
"""
        resp = await openai.ChatCompletion.acreate(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )
        try:
            data = json.loads(resp.choices[0].message.content)
            ok = data.get("ok", ok)
            notes.extend(data.get("notes", []))
        except json.JSONDecodeError:
            notes.append("GPT validation parse error")
    # Update item
    item["ok"] = ok
    item["judge_notes"] = notes
    # Log decision
    ts = datetime.now().isoformat()
    state["decision_log"].append({
        "step": "judge_rewrite",
        "result": "pass" if ok else "fail",
        "time": ts,
        "details": {"notes": notes}
    })
    return state

# rewrite 결과물 추가 node
@graph.node(name="append_node")
def append_node(state: dict) -> dict:
    """
    rewrite item까지 통과된 경우, 최종 누적 처리 표시
    """
    # 단순 flow control, state 자체에 이미 items와 segments가 누적됨
    return state


# 평가 agent
@graph.agent(name="evaluation_agent")
async def evaluation_agent(state: dict) -> dict:
    """
    면접 종료 시 호출됨
    1) 전체 rewritten 텍스트 합치기
    2) GPT 평가 수행
    3) state['evaluation'] 업데이트
    """
    all_text = "\n".join([it["rewritten"] for it in state.get("rewrite", {}).get("items", [])])
    results = await evaluate_keywords_from_full_answer(all_text)
    state["evaluation"] = {"done": True, "results": results, "ok": None, "judge_notes": []}
    ts = datetime.now().isoformat()
    state["decision_log"].append({
        "step": "evaluation_agent",
        "result": "done",
        "time": ts,
        "details": {}
    })
    return state

# judge agent
@graph.agent(name="judge_evaluation")
async def judge_evaluation(state: dict) -> dict:
    """
    평가 결과 검증
    """
    import json
    import openai
    from jsonschema import validate, ValidationError
    # 준비
    results = state.get("evaluation", {}).get("results", {})
    notes = []
    ok = True
    # 1) JSON 스키마 검증 (스키마 정의 생략, 예시에서는 간단 타입 체크)
    schema = {
        "type": "object",
        "additionalProperties": {"type": "object"}
    }
    try:
        validate(results, schema)
    except ValidationError as e:
        ok = False
        notes.append(f"Schema validation error: {e.message}")
    # 2) 룰 검사: 점수 범위 확인
    total = 0
    for comp, detail in results.items():
        scores = detail.get("scores", {})
        comp_sum = sum(s.get("score", 0) for s in scores.values())
        if comp_sum < 3 or comp_sum > 15:
            ok = False
            notes.append(f"{comp} sum out of 3~15: {comp_sum}")
        total += comp_sum
    if total < 0 or total > 150:
        ok = False
        notes.append(f"Total score out of 0~150: {total}")
    # 3) GPT 기반 검증
    if ok:
        prompt = f"""
시스템: 당신은 면접 평가 검증 전문가입니다.
사용자 평과 결과 JSON:
{json.dumps(results)}
기준에 맞는지 JSON { '{"ok":bool, "notes": [str]}' } 형태로 반환하세요.
"""
        resp = await openai.ChatCompletion.acreate(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0
        )
        try:
            data = json.loads(resp.choices[0].message.content)
            ok = data.get("ok", ok)
            notes.extend(data.get("notes", []))
        except json.JSONDecodeError:
            notes.append("GPT eval parse error")
    # 상태 업데이트
    state["evaluation"]["ok"] = ok
    state["evaluation"]["judge_notes"] = notes
    # 로그
    ts = datetime.now().isoformat()
    state["decision_log"].append({
        "step": "judge_evaluation",
        "result": "pass" if ok else "fail",
        "time": ts,
        "details": {"notes": notes}
    })
    return state

# 최종 레포트 pdf node
@graph.node(name="pdf_node")
def pdf_node(state: dict) -> dict:
    """
    PDF 리포트 생성 (report_service 재사용)
    """
    from datetime import datetime
    import os

    # 1) 평가 결과 keyword_results 변환
    keyword_results = {
        kw: {
            "score": sum(v["score"] for v in det["scores"].values()),
            "reasons": "\n".join(v.get("reason", "") for v in det["scores"].values())
        }
        for kw, det in state.get("evaluation", {}).get("results", {}).items()
    }

    # 2) 출력 경로 준비
    cid = state.get("interviewee_id")
    ts = datetime.now().strftime('%Y%m%d%H%M%S')
    out_dir = './results'
    os.makedirs(out_dir, exist_ok=True)
    chart_path = os.path.join(out_dir, f"{cid}_chart_{ts}.png")
    pdf_path = os.path.join(out_dir, f"{cid}_report_{ts}.pdf")

    # 3) report_service의 generate_pdf 호출
    generate_pdf(
        keyword_results=keyword_results,
        chart_path=chart_path,
        output_path=pdf_path,
        interviewee_id=cid,
        qa_blocks_text="",  # 질문-답변 정리 텍스트
        total_score=sum(item.get("score", 0) for item in keyword_results.values())
    )

    # 4) state 업데이트 및 로그 추가
    state.setdefault("report", {}).setdefault("pdf", {})["generated"] = True
    state["report"]["pdf"]["path"] = pdf_path
    ts2 = datetime.now().isoformat()
    state.setdefault("decision_log", []).append({
        "step": "pdf_node",
        "result": "generated",
        "time": ts2,
        "details": {"path": pdf_path}
    })
    return state

# 엑셀 node
@graph.node(name="excel_node")
def excel_node(state: dict) -> dict:
    """
    엑셀 생성 (미구현)
    """
    state.setdefault("report", {})["excel"] = {"generated": False, "path": None}
    return state

# ──────────────── 엔트리포인트 에이전트 ────────────────

@graph.agent(name="interview_pipeline")
async def interview_pipeline(state: dict) -> dict:
    # STT → 리라이팅 → judge 반복
    state = graph.run_node("stt_node", state)
    state = await graph.run_agent("rewrite_agent", state)
    state = await graph.run_node("judge_rewrite", state)
    if not state["rewrite"]["items"][-1]["ok"]:
        # 재실행
        state = await graph.run_agent("rewrite_agent", state)
        state = await graph.run_node("judge_rewrite", state)
    state = graph.run_node("append_node", state)
    return state

@graph.agent(name="end_interview_pipeline")
async def end_interview_pipeline(state: dict) -> dict:
    state["interview_ended"] = True
    state = await graph.run_agent("evaluation_agent", state)
    state = graph.run_node("judge_evaluation", state)
    if not state["evaluation"]["ok"]:
        state = await graph.run_agent("evaluation_agent", state)
        state = graph.run_node("judge_evaluation", state)
    state = graph.run_node("pdf_node", state)
    state = graph.run_node("excel_node", state)
    return state
