# app/pipeline/graph_pipeline.py
from langgraph import Graph
from datetime import datetime
import os

# 서비스 함수 임포트
from app.services.interview.stt_service import transcribe_audio_file
from app.services.interview.rewrite_service import rewrite_answer
from app.services.interview.evaluation_service import evaluate_keywords_from_full_answer
from app.services.interview.report_service import create_radar_chart, generate_pdf

# LangGraph 그래프 인스턴스
graph = Graph()

# ──────────────── 상태(state) 구조 ────────────────
# 각 에이전트/노드 호출 시 인자로 전달됩니다.
# 지원자 단위로 독립 실행 가능하도록 설계되었습니다.
#
# state = {
#     "interviewee_id": str,
#     "interview_ended": bool,
#     "stt": {"done": bool, "segments": [{"raw": str, "timestamp": str}, ...]},
#     "rewrite": {"done": bool, "items": [{"raw": str, "rewritten": str, "ok": bool|None, "judge_notes": [str]}]},
#     "decision_log": [{"step": str, "result": str, "time": str, "details": dict}],
#     "evaluation": {"done": bool, "results": dict|None, "ok": bool|None, "judge_notes": [str]},
#     "report": {"pdf": {"generated": bool, "path": str|None}, "excel": {"generated": bool, "path": str|None}}
# }

# ──────────────── 노드 및 에이전트 정의 ────────────────

#  Available Nodes & Agents
# Nodes  : stt_node, append_node, pdf_node, excel_node
# Agents : rewrite_agent, judge_rewrite, evaluation_agent, judge_evaluation



# stt node
@graph.node(name="stt_node")
def stt_node(state: dict) -> dict:
    """
    1) audio_path 를 읽어 STT 수행
    2) state['stt']['segments']에 원문+타임스탬프 추가
    """
    audio_path = state.get("audio_path")
    interviewee_id = state["interviewee_id"]
    # Whisper API 호출 (이미 WAV 포맷으로 전달된다고 가정)
    raw = transcribe_audio_file(audio_path)
    ts = datetime.now().isoformat()
    # segments 누적
    state.setdefault("stt", {"done": False, "segments": []})
    state["stt"]["segments"].append({"raw": raw, "timestamp": ts})
    state["decision_log"].append({
        "step": "stt_node",
        "result": "success",
        "time": ts,
        "details": {"segment": raw[:30]}  # preview
    })
    return state


# rewrite agent












# rewrite judge agent









# rewrite 결과물 추가 node













# 평가 agent
@graph.agent(name="evaluation_agent")
async def evaluation_agent(state: dict) -> dict:
    """
    면접 종료 시 호출됨
    1) 전체 rewritten 텍스트 합치기
    2) GPT 평가 수행
    3) state['evaluation'] 업데이트
    """
    all_text = "\n".join([it["rewritten"] for it in state.get("rewrite", {}).get("items", [])])
    results = await evaluate_keywords_from_full_answer(all_text)
    state["evaluation"] = {"done": True, "results": results, "ok": None, "judge_notes": []}
    ts = datetime.now().isoformat()
    state["decision_log"].append({
        "step": "evaluation_agent",
        "result": "done",
        "time": ts,
        "details": {}
    })
    return state

# 평가 judge agent
















# 최종 레포트 pdf node











# 엑셀 node






# ──────────────── Pipeline 설계: 면접 종료 후 전체 처리 ────────────────
@graph.pipeline(name="interview_flow")
async def interview_flow(state: dict) -> dict:
    """
    1) 한 번의 발화가 끝나면 호출됩니다.

    2) 아래 순서대로 Node/Agent를 실행하세요.
       - STT Node        : state['audio_path']를 받아 transcript 생성 → state 에 누적
       - Rewrite Agent   : 최신 transcript를 정제 → state['rewrite']에 추가
       - Judge Rewrite   : 정제 결과 품질검증 → ok/notes 업데이트
       - (필요 시 재시도) : ok=False 인 경우 rewrite → judge 재실행
       - Append Node     : 검증 통과된 segment를 최종 누적 처리

    3) 구현 담당자는 각 단계에 graph.run_node(...) / graph.run_agent(...) 처럼 구현하시면 됩니다.
    """


    return state

# ──────────────── Pipeline 설계: 한 발화 단위 처리 ────────────────

@graph.pipeline(name="final_report_flow")
async def final_report_flow(state: dict) -> dict:
    """
    1) 면접 종료 시 한 번만 호출됩니다.

    2) 아래 순서대로 전체 평가 및 리포트 생성 로직을 실행하세요.
       - Evaluation Agent   : 누적된 rewritten 텍스트로 점수화 수행
       - Judge Evaluation   : 평가 결과 검증 → ok/notes 업데이트
       - (필요 시 재시도)    : ok=False 인 경우 evaluation → judge 재실행
       - PDF Node           : PDF 리포트 생성
       - Excel Node         : (미구현) 엑셀 파일 생성

    3) 구현 담당자는 graph.run_agent(...) / graph.run_node(...) 처럼 구현 하시면 됩니다.
  """
    
    return state
