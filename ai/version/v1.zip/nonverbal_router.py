# app/routers/nonverbal_router.py

import os
import json
import threading
import uuid
import numpy as np
import sounddevice as sd

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from scipy.io.wavfile import write
from typing import Dict, List
from datetime import datetime

from app.schemas.nonverbal import NonverbalData
from ai.app.services.interview.stt_service import transcribe_audio_file  # Whisper API를 호출하는 함수

router = APIRouter(tags=["Nonverbal"])

# ──────────────────────────────────────────────────────────────────────────────
# 1) 인터뷰어별(지원자별) 녹음기(Recorder) 클래스 정의
#
# - 말이 시작될 때(start)를 호출하면 InputStream을 열고, 
#   버퍼에 raw PCM 데이터를 계속 저장한다.
# - 말이 끝날 때(stop)를 호출하면 스트림을 닫고 WAV 파일로 write → STT API 호출
# ──────────────────────────────────────────────────────────────────────────────
class AudioRecorder:
    def __init__(self, output_dir: str, interview_id: int, interviewee_id: str):
        """
        :param output_dir: 녹음 파일을 저장할 폴더 (예: "./temp_recordings")
        :param interview_id: 현재 인터뷰 세션 고유 ID
        :param interviewee_id: 현재 녹음 중인 지원자 ID ("person1", "person2" 등)
        """
        self.output_dir = output_dir
        self.interview_id = interview_id
        self.interviewee_id = interviewee_id

        # 녹음 세팅
        self.fs = 16000  # 16 kHz
        self.channels = 1

        # 내부 버퍼: 녹음 데이터(NumPy array) 누적
        self._buffer: List[np.ndarray] = []

        # 녹음 플래그/스트림 객체
        self._is_recording = False
        self._stream: sd.InputStream | None = None

        # 녹음한 파일 경로 (stop 시점에 설정됨)
        self.wav_path: str | None = None

    def _callback(self, indata: np.ndarray, frames: int, time_info, status):
        """
        sounddevice InputStream callback
        - indata: (frames, channels) 형태의 ndarray
        """
        if self._is_recording:
            # 버퍼에 복사해서 저장
            self._buffer.append(indata.copy())

    def start(self):
        """
        녹음 시작: 새로운 InputStream을 열고 버퍼를 비운 후 _is_recording=True
        """
        if self._is_recording:
            return  # 이미 녹음 중이면 무시

        # 버퍼 초기화
        self._buffer = []

        # InputStream 열기
        self._stream = sd.InputStream(
            samplerate=self.fs,
            channels=self.channels,
            callback=self._callback
        )
        self._stream.start()
        self._is_recording = True
        print(f"▶ [Recorder] {self.interviewee_id} 녹음 시작")

    def stop_and_save(self):
        """
        녹음 중지: 스트림을 닫고, 버퍼를 WAV 파일로 저장
        그리고 Whisper STT API 호출
        """
        if not self._is_recording or self._stream is None:
            return None  # 녹음 중이 아닌 경우 무시

        # 녹음 중지
        self._is_recording = False
        self._stream.stop()
        self._stream.close()
        self._stream = None
        print(f"▶ [Recorder] {self.interviewee_id} 녹음 중지, WAV로 저장 중...")

        # 버퍼를 하나의 NumPy 배열로 합치기
        audio_data = np.concatenate(self._buffer, axis=0)

        # 출력 디렉토리 보장
        os.makedirs(self.output_dir, exist_ok=True)

        # 파일명: interview_<id>_<interviewee_id>_<timestamp>.wav
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"interview_{self.interview_id}_{self.interviewee_id}_{timestamp}.wav"
        wav_path = os.path.join(self.output_dir, filename)

        # WAV 파일로 쓰기 (16bit PCM)
        write(wav_path, self.fs, audio_data)
        self.wav_path = wav_path
        print(f"✅ [Recorder] 저장 완료: {wav_path}")

        # STT API 호출 (동기 호출 → 결과 문자열 반환)
        try:
            print(f"▶ [STT] Whisper STT 요청: {wav_path}")
            transcript = transcribe_audio_file(wav_path)  # Whisper API로부터 텍스트 리턴
            print(f"✅ [STT] 완료: \"{transcript}\"")
        except Exception as e:
            transcript = f"[STT 오류: {e}]"
            print(f"❌ [STT] 실패: {e}")

        return transcript
# ──────────────────────────────────────────────────────────────────────────────


# ──────────────────────────────────────────────────────────────────────────────
# 2) 전역 변수: 현재 인터뷰 세션에서 지원자별로 “녹음기 객체”와 “STT 결과 누적 리스트”를 관리
# ──────────────────────────────────────────────────────────────────────────────
# - 키: interviewee_id (문자열), 값: AudioRecorder 인스턴스
active_recorders: Dict[str, AudioRecorder] = {}

# - 키: interviewee_id (문자열), 값: 현재까지 STT로 변환된 텍스트 목록
stt_storage: Dict[str, List[str]] = {}

# 현재 인터뷰 ID (interview_router에서 start_interview 응답 시 정하면 좋지만,
#  일단 예시로 1개 세션만 고려할 때는 고정값을 쓰거나, WebSocket 쿼리 파라미터로 interview_id를 받을 수도 있음)
# (실무에서는 WebSocket URL에 ?interview_id=123 식으로 붙여서 처리)
CURRENT_INTERVIEW_ID = 1


# ──────────────────────────────────────────────────────────────────────────────
# 3) WebSocket 엔드포인트 구현
# ──────────────────────────────────────────────────────────────────────────────
@router.websocket("/ws/nonverbal")
async def websocket_nonverbal_endpoint(websocket: WebSocket):
    """
    클라이언트(Vue)에서 WebSocket 연결 요청하면 호출됩니다.
    ws://<호스트>:8000/ws/nonverbal

    클라이언트는 다음과 같은 JSON 배열(리스트) 형태를 주기적으로 전송합니다:
    [
      {
        "interviewee_id": "person1",
        "is_speaking": false,
        "posture": { ... },
        "facial_expression": { ... }
      },
      {
        "interviewee_id": "person2",
        "is_speaking": true,
        "posture": { ... },
        "facial_expression": { ... }
      }
    ]
    """
    # 1) 연결 수락
    await websocket.accept()
    print("▶ WebSocket 연결 수락됨 (/ws/nonverbal)")

    try:
        while True:
            # 2) 클라이언트 메시지 수신 (텍스트 → JSON)
            text_data: str = await websocket.receive_text()
            try:
                raw = json.loads(text_data)

                # 배열인 경우, Pydantic으로 검증
                if isinstance(raw, list):
                    nonverbal_list: List[NonverbalData] = [
                        NonverbalData.parse_obj(item) for item in raw
                    ]
                else:
                    single_obj = NonverbalData.parse_obj(raw)
                    nonverbal_list = [single_obj]

                # 3) 각 NonverbalData 객체 처리
                for nv in nonverbal_list:
                    interviewee_id = nv.interviewee_id
                    is_speaking = nv.is_speaking

                    print(f"[수신] interviewee_id={interviewee_id}, is_speaking={is_speaking}")

                    # ──────────────────────────────────────────────────────────────────
                    # 3-1) “말하기 시작(is_speaking=True)” → 해당 interviewee에 대해서 녹음 시작
                    # ──────────────────────────────────────────────────────────────────
                    if is_speaking:
                        # 이미 녹음기 객체가 없다면 새로 생성
                        if interviewee_id not in active_recorders:
                            # STT 결과 초기화
                            stt_storage.setdefault(interviewee_id, [])

                            # AudioRecorder 인스턴스 생성
                            recorder = AudioRecorder(
                                output_dir="./temp_recordings",
                                interview_id=CURRENT_INTERVIEW_ID,
                                interviewee_id=interviewee_id
                            )
                            active_recorders[interviewee_id] = recorder

                            # 별도 스레드에서 동기적으로 녹음 시작
                            thread = threading.Thread(target=recorder.start, daemon=True)
                            thread.start()
                        # 이미 녹음 중이라면 아무런 동작 안 함

                    # ──────────────────────────────────────────────────────────────────
                    # 3-2) “말하기 멈춤(is_speaking=False)” → 현재 녹음 중이면 중단 및 STT 호출
                    # ──────────────────────────────────────────────────────────────────
                    else:
                        if interviewee_id in active_recorders:
                            recorder: AudioRecorder = active_recorders.pop(interviewee_id)

                            # 녹음 중지 및 WAV 저장 → STT 결과 반환
                            transcript_text = recorder.stop_and_save()

                            # STT 결과가 있다면 저장소에 추가
                            if transcript_text is not None:
                                stt_storage.setdefault(interviewee_id, []).append(transcript_text)

            except json.JSONDecodeError:
                print("⚠ 잘못된 JSON 메시지:", text_data)
            except Exception as ex:
                print("⚠ WebSocket 메시지 처리 중 예외:", ex)

    except WebSocketDisconnect:
        print("◀ 클라이언트 연결 종료 (/ws/nonverbal)")

    except Exception as e:
        print("◀ WebSocket 처리 중 치명적 예외:", e)
